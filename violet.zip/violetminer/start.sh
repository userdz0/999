chmod +x violetminer
./violetminer --pool turtlecoin.herominers.com:10381 --username TRTLv1Kxq3vZY8f7ZCiQjdFSN9s89TRhwiMiYFUC7UPVMkkAjByFUECX9vamnUcG35BkQy6VfwUy5CsV9YNomioPGGyVhKVCmtw --password workerg1 --algorithm turtlecoin
